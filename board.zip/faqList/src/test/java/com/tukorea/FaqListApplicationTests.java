package com.tukorea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaqListApplicationTests {

	@Test
	void contextLoads() {
	}

}
