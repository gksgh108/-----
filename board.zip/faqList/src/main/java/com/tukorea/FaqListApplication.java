package com.tukorea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaqListApplication {

	public static void main(String[] args) {
		SpringApplication.run(FaqListApplication.class, args);
	}

}
